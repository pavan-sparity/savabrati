import React from 'react';
import User_P from '../utilities/User_P';

const UserPanel = () => {
  return (
    <div>
        <User_P />
    </div>
  )
}

export default UserPanel;