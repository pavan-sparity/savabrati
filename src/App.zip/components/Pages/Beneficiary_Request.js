import React from 'react';
import B_Request from '../utilities/B_Request';

const Beneficiary_Request = () => {
  return (
    <div>
        <B_Request />
    </div>
  )
}

export default Beneficiary_Request