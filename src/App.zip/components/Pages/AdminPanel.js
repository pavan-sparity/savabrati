import React from 'react';
import Apanel from '../utilities/Apanel';

const AdminPanel = () => {
  return (
    <div>
        <Apanel />
    </div>
  )
}

export default AdminPanel