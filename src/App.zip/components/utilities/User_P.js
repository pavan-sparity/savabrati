import React from 'react';
import './Apanel.css';
import { 
    Container,
    Col,
    Button,
    Row
    
} from 'reactstrap';

const User_P = () => {
  return (
    
    <div>
<Container>
        <Row>
    <Col
      className="bg-light border admin"
      lg="12"
      
    >
      Welcome User
    </Col>
  </Row>


  <Row>
    <Col
      className="bg-light border"
      xs="4"
      block
    >
<div>
  <Button
  block
    color="info"
  >
    Manage Users
  </Button>
</div>

<div>
  <Button
  block
    color="info"
  >
    Manage Requests
  </Button>
</div>

<div>
  <Button
  block
    color="info"
  >
    Manage Feedback
  </Button>
</div>

<div>
  <Button
  block
    color="info"
  >
    Manage Enquiry
  </Button>
</div>
    </Col>
    <Col
      className="bg-light border"
      xs="6"
    >
      .col-6
    </Col>
    <Col
      className="bg-light border"
      xs="2"
    >
      
    </Col>
  </Row>

        </Container>
    </div>
  )
}

export default User_P