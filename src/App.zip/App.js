import React from "react";
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import { Button } from 'reactstrap';
import AdminPanel from "./components/Pages/AdminPanel";
import SignUpPage from "./components/Pages/SignUpPage";
import Beneficiary_Request from "./components/Pages/Beneficiary_Request";
import Mobile_OTP_Page from "./components/Pages/Mobile_OTP_Page";
import UserPanel from "./components/Pages/UserPanel";
import NavBar_All from "./components/utilities/NavBar_All";
import Home from "./components/Pages/Home";
import AboutUs from './components/utilities/AboutUs';
import Team from './components/utilities/Team';
import ContactUs from './components/utilities/ContactUs';
import AdminLogin from "./components/utilities/AdminLogin";
import User_P from "./components/utilities/User_P";

export default (props) => {
  return (
    <div>
      {/* <SignUpPage /> */}
      {/* <AdminPanel /> */}
      {/* <Beneficiary_Request /> */}
      {/* <Mobile_OTP_Page /> */}
      {/* <UserPanel /> */}
      {/* <NavBar_All/> */}


      <NavBar_All />
      
      <Routes>

      <Route path='/signup' element={<Mobile_OTP_Page />} exact />
      <Route path='/login' element={<Mobile_OTP_Page/>} />
      <Route path='/' element={<Home/>}/>
      <Route path='/aboutus' element={<AboutUs/>} />
      <Route path='/team' element={<Team/>} />
      <Route path='/contactus' element={<ContactUs/>}/>
      <Route path='/adminlogin' element={<AdminLogin/>}/>


    
      


      </Routes>
      {/* <User_P/> */}

    </div>
  
  
    //  <Button color="danger">Danger!</Button>
    
  );
}

// export default App;
